#include <iostream>
#include <string>
#include <math.h>
#include <cstring>
#include <vector>
#include <fstream>
#include <random>
#include <stdlib.h>
// #include <unordered_map>
#include <map>

#include "class.h"
#include "fus_declaration.h"

#define def_K_vec 4
#define def_L_grid 4
// #define W 2000.0

using namespace std;


bool check_args(int argc, const char * argv[], string * input_file, string * query_file, int * k_vec, int * l_grid, string * output_file)
{

  if(argc == 11)
  {
    for(int i = 0; i < 10; i++)
    {
      if(strcmp(argv[i], "-d") == 0 )
      {
        if(input_file->length() == 0)
          input_file->append(argv[i+1]);
        else
          return false;
      }
      if(strcmp(argv[i], "-q") == 0)
      {
        if(query_file->length() == 0)
        {
          query_file->append(argv[i+1]);
        }
        else
          return false;
      }
      if(strcmp(argv[i], "-k_vec") == 0 )
      {
        if(*k_vec == -1)
          *k_vec = atoi(argv[i+1]);
        else
          return false;
      }
      if(strcmp(argv[i], "-L_grid") == 0 )
      {
        if(*l_grid == -1)
          *l_grid = atoi(argv[i+1]);
        else
          return false;
      }
      if(strcmp(argv[i], "-o") == 0)
      {
        if(output_file->length() == 0)
        {
          output_file->append(argv[i+1]);
        }
        else
          return false;
      }
    }
  }
  else if(argc == 7)
  {
    for(int i = 1; i < 7; i++)
    {
      if(strcmp(argv[i], "-d") == 0 )
      {
        if(input_file->length() == 0)
          *input_file = argv[i+1];
        else
          return false;
      }
      if(strcmp(argv[i], "-q") == 0)
      {
        if(query_file->length() == 0)
        {
          query_file->append(argv[i+1]);
        }
        else
          return false;
      }
      if(strcmp(argv[i], "-o") == 0)
      {
        if(output_file->length() == 0)
        {
          output_file->append(argv[i+1]);
        }
        else
          return false;
      }
    }

    *k_vec = def_K_vec;
    *l_grid = def_L_grid;
  }
  else if(argc == 1)
  {
    *k_vec = def_K_vec;
    *l_grid = def_L_grid;

    cout << "Please give the input_file" << endl;
    cin >> *input_file;
    cout << "Please give the query_file" << endl;
    cin >> *query_file;
    cout << "Please give the output_file" << endl;
    cin >> *output_file;
  }
  else
  {
    cout<< "ERROR" << endl;
    return false;
  }

  return true;
}

double dtw(curve * P, curve * Q)
{
	int dim_p = P->get_p_num();
	int dim_q = Q->get_p_num();

	vector<vector<double> > DTW;
	vector<Point *> points_P = P->get_points();
	vector<Point *> points_Q = Q->get_points();

	double dist = 0.0;

	for(int i = 0; i < dim_p; i++) // points of curve P
	{
		vector<double> line;
		for(int j = 0; j < dim_q; j++) // points of curve Q
		{
			if(i == 0 && j == 0)
				dist = point_dist(points_P[i], points_Q[j]); // first point distance
			else if(i == 0)
				dist = line[j-1] + point_dist(points_P[i], points_Q[j]);
			else if(j == 0)
				dist = DTW[i-1].at(j) + point_dist(points_P[i], points_Q[j]);
			else
			{
				dist = point_dist(points_P[i], points_Q[j]); // point distance

				// find min from near matrix positions
				if(line[j-1] <= DTW[i-1].at(j) && line[j-1] <= DTW[i-1].at(j-1))
					dist += line[j-1];
				else if(DTW[i-1].at(j) <= line[j-1] && DTW[i-1].at(j) <= DTW[i-1].at(j-1))
					dist += DTW[i-1].at(j);
				else
					dist += DTW[i-1].at(j-1);
			}

			line.push_back(dist);
		}
		DTW.push_back(line);
	}
	return DTW[dim_p - 1].at(dim_q - 1);
}

double point_dist(Point * x1, Point * x2)
{
	double pow_x = pow(x1->get_x() - x2->get_x(), 2);
	double pow_y = pow(x1->get_y() - x2->get_y(), 2);

	double res = pow_x + pow_y;
	res = sqrt(res);

	return res;
}

vector<int> create_Gd(int dim, int delta)
{
	vector<int> Gd;

	for(int i = 0; i < dim; i++)
		Gd.push_back(delta);

	return Gd;
}

vector<double> create_t(int dim)
{
	random_device rd;
	mt19937 gen (rd ());
	uniform_real_distribution <double> dis (0.0, dim);

	vector<double> t;
	for(int i = 0; i < dim; i++)
	{
		t.push_back(dis(gen));
	}
	return t;
}

vector<vector<double>> create_grid_curve(vector<curve *> P, vector<int> Gd, vector<double> t, int size)
{

  vector<vector<double>> H;

  vector<Point *> curve_vec1 = P[0]->get_points();

  // for(int i = 0; i <curve_vec1.size(); i ++)
  //     cout<<curve_vec1[i]->get_x()<<" "<<curve_vec1[i]->get_y()<<endl;



  for(int p = 0; p < P.size(); p++)
  {
    vector<Point *> Hi;

    vector<Point *> curve_vec = P[p]->get_points();

    // for(int i = 0; i <curve_vec.size(); i ++)
      // cout<<curve_vec[i]->get_x()<<" "<<curve_vec[i]->get_y()<<endl;

    for(int i = 0; i < curve_vec.size(); i++)
    {

      int a1 = -t[0]/Gd[0] + curve_vec[i]->get_x()/Gd[0];
      int a2 = -t[1]/Gd[1] + curve_vec[i]->get_y()/Gd[1];

      // cout<<a1<<" "<<a2<<endl;

      Point * P1 = new Point(a1, a2);
      double dist1 = point_dist(curve_vec[i], P1);

      Point * PP = new Point(a1*Gd[0]+t[0], a2*Gd[1]+t[1]);
      Hi.push_back(PP);

    }
    // remove consecutive duplicates
    vector<Point *> New_Hi;
    New_Hi.push_back(Hi[0]);
    for(int i = 1; i < Hi.size(); i++)
    {
      if(Hi[i-1]->get_x() != Hi[i]->get_x() || Hi[i-1]->get_y() != Hi[i]->get_y())
      {
        New_Hi.push_back(Hi[i]);
      }
    }
    vector<double> vv;
    for(int i = 0; i < New_Hi.size(); i++)
    {
      vv.push_back(New_Hi[i]->get_x());
      vv.push_back(New_Hi[i]->get_y());
    }

    // padding
    for(int i = vv.size() - 1; i < size; i++)
      vv.push_back(10000);

    H.push_back(vv);

  }

  return H;
}

//  FUN TO STORE THE CURVES DATASET
vector <curve *> store_curves (string fname, int * m)
{
  int id=0, i, str_start, str_end;
  string curve_line, id_str, p_num_str, x_str;
  Point *p;
  vector <Point *> pvec;
  curve *c;
  vector <curve *> cvec;

  int min = -1;

  fstream myfile (fname);
  if (myfile.is_open ())
  {
    while (getline (myfile, curve_line))
    {
      c = new curve ();

      str_start=0;
      str_end=curve_line.find ("\t", str_start);

      // cout << "brethike sto " << str_end << endl;

      if (str_start==std::string::npos)
        continue;

      id_str=curve_line.substr (str_start, str_end-str_start);

      c->set_id (id);
      c->set_str_id (id_str);
      // cout << "id=" << id << " -- id_str=" << id_str << endl;

      str_start=str_end+1;
      str_end=curve_line.find ("\t", str_start);
      p_num_str=curve_line.substr (str_start, str_end-str_start);
      // cout << "p_num=" << p_num_str << endl;
      c->set_p_num (stoi (p_num_str));
      if(min == -1)
      {
        min = stoi (p_num_str);
      }
      else if(min > stoi (p_num_str))
      {
        min = stoi (p_num_str);
      }

      for (i=0; i<stoi (p_num_str); i++)
      {
        p = new Point();
        str_start=curve_line.find ("(", str_end+1)+1;

        str_end=curve_line.find (",", str_start);
        x_str=curve_line.substr (str_start, str_end-str_start);
        p->set_x (stod (x_str));
        // cout << "x=" << x_str << endl;

        str_start=str_end+1;
        str_end=curve_line.find (")", str_start);
        x_str=curve_line.substr (str_start, str_end-str_start);
        p->set_y (stod (x_str));
        // cout << "y=" << x_str << endl;

        pvec.push_back (p);
      }

      c->set_points (pvec);
      pvec.clear ();

      cvec.push_back (c);

      id++;
    }
  }

  *m = min;
  return cvec;
}

//////////////////////////////////////////////////

vector <vector_info *> make_vecs_objects (vector <vector <double>> vecs)
{
  int i, dim=vecs[0].size ();
  vector_info *v;
  vector <vector_info *> all_v;

  for (i=0; i<vecs.size (); i++)
  {
    v=new vector_info ();
    v->set_id (i);
    v->set_dim (dim);
    v->set_all_coord (vecs[i]);

    all_v.push_back (v);
  }

  return all_v;
}


vector <double> random_s (int dim, double W)
{
	int i;
	vector <double> v;
	random_device rd;
	mt19937 gen (rd ());
	uniform_real_distribution <double> dis (0.0, W);

	for (i=0; i<dim; i++)
		v.push_back (dis (gen));

	return v;
}


vector <vector <vector <double>>> every_s (int L, int K, int dim, double W)
{
	int i, j;
	vector <vector <double>> ks;
	vector <vector <vector <double>>> lks;

	for (i=0; i<L; i++)
	{
		for (j=0; j<K; j++)
			ks.push_back (random_s(dim, W));
		lks.push_back(ks);
		ks.clear();
	}

	return lks;
}


double compute_w (vector <trueNN_node *> v)
{
	int i, j, sum=0, size=v.size ();
  double w;
	for (i=0; i<size; i++)
    sum+=v[i]->get_min_dist ();

  return 10.0*sum/size;
}


vector <int> compute_a (vector_info *x, vector <double> s, double W)
{
	int i, val;
	double dif;

	vector <int> a;

	for (i=0; i<x->get_dim (); i++)
	{
		dif=x->get_specific_coord(i) - s[i];
		val = floor(dif/W);

		a.push_back (val);
	}
	return a;
}


vector <vector <vector <int>>> a_for_each_x (vector_info* x, vector <vector <vector <double>>> s, int L, int K, int dim, double W)
{
	int i, j, z;
	vector <vector <int>> ka;
	vector <vector <vector <int>>> lka;

	for (i=0; i<L; i++)
	{
		for (j=0; j<K; j++)
			ka.push_back(compute_a(x, s[i].at(j), W));

		lka.push_back(ka);
		ka.clear ();
	}

	return lka;
}


int compute_m (vector <vector <vector <vector <int>>>> a)
{
	int i, j, k, l, max=-1;

	for (i=0; i<a.size (); i++)
	{
		for (j=0; j<a[0].size (); j++)
		{
			for (k=0; k<a[0].at(0).size (); k++)
			{
				for (l=0; l<a[0].at(0).at (0).size (); l++)
				{
					if (a[i].at (j).at (k).at (l)>max)
						max=a[i].at (j).at (k).at (l);
				}
			}
		}
	}

	return max + 1;
}


int mymod (int a, int b)
{
  int m=a%b;

  if (m<0)
	{
		if (b<0)
			m=m-b;
		else
		m=m+b;
  }

  return m;
}


int modpow (int x, int y, int p)
{
    int res=1;      // Initialize result

    x=x%p;  // Update x if it is more than or
                // equal to p

    while (y>0)
    {
        // If y is odd, multiply x with result
        if (y&1)
            res=(res*x)%p;

        // y must be even now
        y = y>>1; // y = y/2
        x = (x*x)%p;
    }
    return res;
}


int compute_h (vector <int> a, int d, int m, int M)
{
	int i, h=0, modmult, power;
	long long int mult;

	// A^B mod C = ( (A mod C)^B ) mod C
	// (A * B ) mod C = (A mod C * B mod C) mod C

	for (i=0; i<a.size (); i++)
	{
		power=modpow (m, i, M);
		mult=power*(mymod (a[d-i-1], M));
		h+=mymod (mult, M);
	}

	h=mymod (h, M);

	return h;
}

vector <vector <vector <int>>> h_for_each_x (vector <vector <vector <vector <int>>>> a, int L, int K, int m, int M)
{
	int i, j, t, z;
	vector <int> kh;
	vector <vector <int>> lkh;
	vector <vector <vector <int>>> xlkh;

	for (i=0; i<a.size (); i++)
	{
		for (j=0; j<L; j++)
		{
			for (t=0; t<K; t++)
				kh.push_back (compute_h (a[i].at(j).at(t), a[0].at(0).at(0).size(), m, M));

			lkh.push_back (kh);
			kh.clear ();
		}

		xlkh.push_back(lkh);
		lkh.clear ();
	}

	return xlkh;
}


long long int compute_g (vector <int> h)
{
  long long int g;
  int i;
  string hi_str="";

  for (i=0; i<h.size (); i++)
    hi_str+=to_string (h[i]);

  g=stoll (hi_str);

  return g;
}


vector <vector <long long int>> every_g (vector <vector <vector <int>>> h)
{
	int i, j;
	vector <long long int> g;
	vector <vector <long long int>> xg;

	for (i=0; i<h.size (); i++)
	{
		for (j=0; j<h[0].size (); j++)
			g.push_back (compute_g (h[i].at(j)));

		xg.push_back (g);
		g.clear ();
	}

	return xg;
}


int hashing (long long int x, long long int size)
{
	int pos;
	long long int y, mult;

	y=x/size;
	mult=y*size;

	pos=x-mult;

	return pos;
}

vector <vector <hash_node *>> match_g_and_x (vector <vector <long long int>> g)
{
	int i, j;
	hash_node *hn;
	vector <hash_node *> gval;
	vector <vector <hash_node *>> l_gval;

	for (j = 0; j < g[0].size (); j++)
	{
		for (i = 0; i < g.size (); i++)
		{
			hn = new hash_node ();
			hn->set_id (i);
			hn->set_g (g[i].at(j));
			gval.push_back (hn);
		}

		l_gval.push_back (gval);
		gval.clear ();
	}


	return l_gval;
}

vector <bucket **> make_L_hashtables (vector <vector <hash_node *>> hn, int L, int size)
{
	int i, j, pos;
	long long int g;
	vector <bucket **> l_hashtables;
	bucket ** hashtable = new bucket *[size];

	for (i = 0; i < L; i++)
	{
		for (j = 0; j < size; j++)
			hashtable[j] = NULL;

		for (j = 0; j < hn[0].size(); j++)
		{
			g = hn[i].at(j)->get_g();
			pos = hashing(g, size);

			if (hashtable[pos] == NULL)
				hashtable[pos] = new bucket;

			hashtable[pos]->add_node(hn[i].at(j));
      // hn[i].at(j)->print_info ();
		}

		l_hashtables.push_back(hashtable);
	}

	return l_hashtables;
}


vector <vector <hash_node *>> find_possible_nns (vector <bucket **> hashtables, int size, vector <vector <long long int>> q_g)
{
  int i, j, k, pos, found;
  bucket **buckets;
  vector <hash_node *> same_bucket;
  vector <vector <hash_node *>> nns;
  hash_node * empty = NULL;

  for (i=0; i < q_g.size (); i++)
  {
    found=0;
    for (j=0; j<hashtables.size (); j++)
    {
      buckets=hashtables[j];
      pos = hashing (q_g[i].at(j), size);
      if(buckets[pos] != NULL)
      {
        for (k=0; k < buckets[pos]->get_all_nodes().size (); k++)
        {
          if (q_g[i].at(j) == buckets[pos]->get_specific_hash_node(k)->get_g())
          {
              found=1;
              same_bucket.push_back(buckets[pos]->get_specific_hash_node(k));
          }

        }
      }
    }
    if (found == 0)
      	same_bucket.push_back(empty);

    nns.push_back (same_bucket);
    same_bucket.clear ();
  }

  return nns;
}


vector <LSH_neig *> find_nn (vector <vector <hash_node *>> posibol, vector <vector <long long int>> q_g, vector<vector_info *> dataset, vector<vector_info *> queries, clock_t t)
{
  int i, j, k, nearest, dist = 0, near_pos;
  vector <LSH_neig * > nns;
  clock_t time = 0.0;

  // vector <vector <hash_node *>> posibol = find_possible_nns (hashtables, size, q_g);

  for (i=0; i<posibol.size (); i++)
  {
    nearest = -1;
    time = clock();
    for (j=0; j<posibol[i].size (); j++)
    {
    	if(posibol[i].at(j) == NULL) // no neighbors
    	{
    		near_pos = -1;
    		nearest = -1;
    	}
    	else
    	{
    		int id = posibol[i].at(j)->get_id();
    		dist = compute_dist(dataset.at(id), queries.at(i));       //allaksa to -1

    		if(nearest == -1)
    		{
    			nearest = dist;
    			near_pos = id;
    		}
    		else
    		{
    			if(nearest > dist)
    			{
    				nearest = dist;
    				near_pos = id;
    			}
    		}
    	}
    }
    time = clock() - time + t;

    LSH_neig * neig = new LSH_neig;
    neig->set_id(near_pos);
    neig->set_dist(nearest);
    neig->set_time((float)time/CLOCKS_PER_SEC);
    nns.push_back(neig);

  }
  return nns;
}


double compute_dist (vector_info *x, vector_info *y)
{
  int i;
  double sum=0.0;

  for (i=0; i< x->get_dim (); i++)
    sum+=abs (x->get_specific_coord(i) - y->get_specific_coord(i));

  return sum;
}


vector <trueNN_node *> find_trueNN (vector <vector_info *> dataset, vector <vector_info *> queries)
{
	int i, j, m, posmin;
  double sum, min_sum;
	trueNN_node *node;
	vector <trueNN_node *> trueNN;
	clock_t time;

	for (i = 0; i<queries.size (); i++)
	{
		time = clock();
		node=new trueNN_node ();

		for (j = 0; j<dataset.size (); j++)
		{
			sum=compute_dist (dataset[j], queries[i]);

			if (j == 0)
			{
        		posmin = j;
        		min_sum = sum;
			}
			else
			{
				if (sum < min_sum)
				{
					min_sum = sum;
          posmin = j;
				}
			}
		}
		cout << "min_dist=" << min_sum << endl;
		time = clock() - time;
  	node->set_id (posmin);
  	node->set_min_dist (min_sum);
  	node->set_time((float)time/CLOCKS_PER_SEC);
  	// node->print_info ();
		trueNN.push_back (node);
	}
	// cout << endl;
	return trueNN;
}


bool write_output(string output_file, vector<LSH_neig *> NN, vector<trueNN_node *> tr, vector<vector_info *> queries, vector<vector_info *> dataset)
{
	ofstream file (output_file);

	for(int i = 0; i < NN.size(); i ++) // for every meighbor
	{
		file << "Query: ";
		file << queries[i]->get_id()<<endl;                 // str_id

		if(NN[i]->get_id() != -1)
		{

			file << "Nearest neighbor: ";
			file << dataset[NN[i]->get_id()]->get_id() << endl; // ALLAKSA TO -1 GIATI EFTIAKSA TA ID -- str_id

			file << "DistanceLSH: ";
			file << NN[i]->get_dist() << endl;

			file << "DistanceTrue: ";
			file << tr[i]->get_min_dist()<<endl;

			file << "tLSH: ";
			file << NN[i]->get_time() << endl;

			file << "tTrue: ";
			file << tr[i]->get_time()<<endl;
		}
		else
		{
			file << "Nearest neighbor: No neighbor with LSH"<<endl;

			file << "DistanceLSH: inf"<<endl;

			file << "DistanceTrue: ";
			file << tr[i]->get_min_dist()<<endl;
		}
		file << endl;

	}

	file.close();

	return true;
}
