#include <iostream>
#include <cmath>
#include <vector>
#include <map>
#include "class.h"
#include "fus_declaration.h"

#define d 2
#define mysize 10
#define L 4
#define TABLESIZE 1024

using namespace std;

int main(int argc, char const *argv[])
{

	string input_file, query_file, output_file;
	int k_vec = -1, l_grid = -1;

	check_args(argc, argv, &input_file, & query_file, &k_vec, &l_grid, &output_file);

	int m, q_m;

	vector<curve *> P = store_curves(input_file, &m);
	vector<curve *> queries = store_curves(query_file, &q_m);
	cout<<queries.size()<<endl;

	int delta = 4 * d * m - 7, q_delta=4*d*q_m;

	vector<int> Gd = create_Gd(d, delta), q_Gd=create_Gd(d, q_delta);

	vector<vector<double>> all_t;
	vector<vector<vector<double>>> all_H, q_all_H;

	for(int i = 0; i < l_grid; i++)
	{
		vector<double> t = create_t(d);
		vector<vector<double>> H, q_H;
		H = create_grid_curve(P, Gd, t, mysize);
		q_H=create_grid_curve(queries, q_Gd, t, mysize);

		all_t.push_back(t);
		all_H.push_back(H);
		q_all_H.push_back (q_H);
	}

	// cout<<q_all_H.size()<<endl;

	// int i = 0, j = 0;
	// // for (int i=0; i<all_H.size(); i++)
	// // {
	// 	for (int j=0; j<all_H[i].size(); j++)
	// 	{
	// 		for (int k=0; k<all_H[i][j].size(); k++)
	// 			cout << all_H[i][j][k] << "  ";
	// 		cout << endl;
	// 	}
	// 	// cout << endl;
	// // }

	//////////////////////////////////

	int i, j, m_lsh, M;
	vector <vector <vector_info *>> all_vecs, q_all_vecs;
	// vector <vector <bucket **>> hashtables;

	for (i=0; i<all_H.size (); i++)
		all_vecs.push_back (make_vecs_objects (all_H[i]));

	for (i=0; i<q_all_H.size (); i++)
		q_all_vecs.push_back (make_vecs_objects (q_all_H[i]));

	// cout << "grids=" << q_all_vecs.size () << endl;
	// cout << "vecs=" << q_all_vecs[1].size () << endl;
	// for (i=0; i<all_vecs.size (); i++)
	// {
	// 	for (j=0; j<all_vecs.size (); j++)
	// 		all_vecs[i][j]->print_info ();
	// }

	for (i=0; i<l_grid; i++)
	{
		vector <vector <vector <double>>> s;
		vector <vector <vector <vector <int>>>> a, q_a;
		vector <vector <vector <int>>> h, q_h;
		vector <vector <long long int>> g, q_g;
		vector <vector <hash_node *>> g_x;
		vector <bucket **> hashtables;
		vector <trueNN_node *> tr = find_trueNN (all_vecs[i], q_all_vecs[i]);
		double R=-1.0, W=compute_w (tr);

		s = every_s (L, k_vec, all_vecs[i].at (0)->get_dim(), W);

		for (j=0; j<all_vecs[i].size(); j++)
	    a.push_back(a_for_each_x (all_vecs[i].at (j), s, L, k_vec, all_vecs[i].at (0)->get_dim(), W));

		m_lsh = compute_m(a);
		// m_lsh++;					//possible

		M=pow (2, 32/k_vec);
	  	h=h_for_each_x (a, L, k_vec, m_lsh, M);
	  	g=every_g (h);
		g_x = match_g_and_x (g);

		hashtables=make_L_hashtables (g_x, L, TABLESIZE);
		// hashtables.push_back (make_L_hashtables (g_x, L, TABLESIZE));

		a.clear ();
	  	h.clear ();
	  	g.clear ();
	  	g_x.clear ();

		for (j=0; j<q_all_vecs[i].size(); j++)
	    	q_a.push_back(a_for_each_x (q_all_vecs[i].at (j), s, L, k_vec, q_all_vecs[i].at (0)->get_dim(), W));

		q_h=h_for_each_x(q_a, L, k_vec, m_lsh, M);
	  	q_g=every_g(q_h);

		vector <vector <hash_node *>> posibol = find_possible_nns(hashtables, TABLESIZE, q_g);

	  	vector <LSH_neig *> NN = find_nn (posibol, q_g, all_vecs[i], q_all_vecs[i], 0);
		// cout << "AA" << endl;
		// if(write_output(output_file, NN, tr, all_vecs[i], q_all_vecs[i]) != true)
	  //   return -1;


		double sum=0.0;
		for (j=0; j<q_all_vecs[i].size (); j++)
		{
	  		cout << "min dist=" << tr[j]->get_min_dist () << " -- lsh dist=" << NN[j]->get_dist () << endl;
			sum+=tr[j]->get_min_dist ()/NN[j]->get_dist ();
		}
		cout << "ratio=" << sum/q_all_vecs[i].size () << endl;

		q_a.clear ();
		s.clear ();
		q_h.clear ();
		q_g.clear ();
		hashtables.clear ();

		// break;
	}

	return 0;
}
