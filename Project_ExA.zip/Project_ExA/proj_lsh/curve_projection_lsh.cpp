#include <iostream>
#include <string>
#include <vector>
#include <math.h>
#include "fus_declaration.h"

using namespace std;

int main(int argc, char const *argv[])
{

	string input_file, output_file, query_file;
	int l_vec, k_vec;
	int d = 2;
	double e;
	check_args(argc, argv, &input_file, &query_file, &k_vec, &l_vec, &e, &output_file);

	int M = 0, not_imp = 0;

	cout<<input_file<<endl;
	vector<curve *> Curves = store_curves(input_file, &M);
	vector<curve *> Curves_q = store_curves(query_file, &not_imp);


	M = 10;
	cout<<M<<endl;
	// return -1;
	// M = 5;

	vector<vector<vector<vector<Point *>>>> All_Rel;
	vector<vector<vector<lsh *>>> All_lsh; // for each i (grammi pinaka) , for each j, for every trajectory

	for(int x = 1; x < M; x++)
	{
		vector<vector<vector<Point *>>> Curr_Rel;
		for(int y = 1; y < M; y++)
		{
			double a = find_a(x, y);
			vector<Point * > allowed = create_possible_tr(x, y, a);

			// for(int i = 0; i < allowed.size(); i++)
				// cout<<allowed[i]->get_x()<<" "<<allowed[i]->get_y()<<endl;

			vector<Point *> init_pos;
			Point * pp = new Point(0,0);
			init_pos.push_back(pp);

		    vector<vector<Point *>> Relevant;
		    vector<vector<Point *>> More;

		    More.push_back(init_pos);


		    while(More.size() != 0)
		    {
		    	// cout<<"while"<<endl;
		    	vector<vector<Point *>> New_More;
		    	for(int i = 0; i < More.size(); i++)
		    	{
		    		vector<vector<Point *>> curr_More = find_relevant(allowed, More[i]);

		    		for(int k = 0; k < curr_More.size(); k++)
		    		{
		    			Point * last = curr_More[k].at(curr_More[k].size()-1);
		    			if(last->get_x() != x-1 && last->get_y() != y-1)
		    				New_More.push_back(curr_More[k]);
		    			else
		    				Relevant.push_back(curr_More[k]);
		    		}
		    	}
		    	More = New_More;
		    }

			Curr_Rel.push_back(Relevant);
		}
		All_Rel.push_back(Curr_Rel);
	}

cout<<"Relevant created"<<endl;
	vector<vector<double>> G_matr = create_G_matr(d, e);

	// vector<vector<vector<lsh *>>> All_lsh;
	vector<vector<vector<vector<double>>>> GU_of_all_curves;

	int i = 0;
	for(int i = 0; i < Curves.size(); i++) // for each input curve
	{
		int size = Curves[i]->get_p_num();
		// cout<<size<<endl;
		// cout<<All_Rel.size()<<endl;
		vector<vector<vector<Point *>>> j_curves = All_Rel[size - 1];

		vector<vector<vector<double>>> GU_of_all_trav_of_all_sizes;

		for(int j = 0; j < j_curves.size(); j++) // for each j
		{
			vector<vector<double>> GU_of_all_trav;
			for(int k = 0; k < j_curves[j].size(); k++) // for each traversal in i, j cell
			{
				// XAMOS!!!!!!!!!
				vector<double> FinalGU;
				for(int pos = 0; pos < j_curves[j].at(k).size(); pos++)
				{
					Point * point = Curves[i]->get_specific_point(j_curves[j].at(k).at(pos)->get_x());
					vector<double> GU = multiply(G_matr, point);
					for(int gu = 0; gu < GU.size(); gu++)
					{
						FinalGU.push_back(GU[gu]);
					}
					GU.clear();
				}
				GU_of_all_trav.push_back(FinalGU);

			}
			GU_of_all_trav_of_all_sizes.push_back(GU_of_all_trav);
		}
		GU_of_all_curves.push_back(GU_of_all_trav_of_all_sizes);
	}


cout<<"GU created"<<endl;
	// initialize all lsh
	for(int i = 0; i < M; i++)
	{
		vector<vector<lsh *>> tem;
		for(int j = 0; j < M; j++)
		{
			vector<lsh *> v;
			tem.push_back(v);
		}
		All_lsh.push_back(tem);
	}

	vector_info *v;
	int M_lsh=pow (2, 32/k_vec), TABLESIZE=1024, m_lsh=32771;
	double W=4000.0;
	lsh *l_ptr;
	vector <lsh *> every_lsh;

	// cout << "AA" << endl;

	for(int i = 0; i < Curves.size(); i ++)
	{
		curve * cc= Curves[i]; // current Curve
		int size = cc->get_p_num(); // size of curve

		for(int j = 0; j < GU_of_all_curves[i].size(); j ++)
		{
			for(int k = 0; k < GU_of_all_curves[i][j].size(); k++)
			{
				v = make_vec_object (GU_of_all_curves[i][j].at (k));
				if(All_lsh[size-1].at(j).size() <= k) // No lsh for this trajectory yet
				{
					vector <vector <vector <double>>> s = every_s(l_vec, k_vec, v->get_dim (), W);
					vector <vector <vector <int>>> a = a_for_each_x(v, s, l_vec, k_vec, v->get_dim(), W);
					vector <vector <int>> h = h_for_each_x (a, l_vec, k_vec, m_lsh, M_lsh);
					vector <long long int> g = every_g (h);
					vector <hash_node *> g_x = match_g_and_x (g);

					lsh * new_lsh = new lsh();
					All_lsh[size-1].at(j).push_back(new_lsh);

					All_lsh[size-1].at(j).at(k)->set_hashtables(l_hashtables_init (TABLESIZE, l_vec));
					All_lsh[size-1].at(j).at(k)->set_hashtables(add_to_L_hashtables (All_lsh[size-1].at(j).at(k)->get_hashtables (), g_x, l_vec, TABLESIZE));
					a.clear ();
					h.clear ();
					g.clear ();
					g_x.clear ();
				}
				else
				{
					vector <vector <vector <int>>> a = a_for_each_x (v, every_lsh[size-1]->get_s (), l_vec, k_vec, v->get_dim(), W);
					vector <vector <int>> h = h_for_each_x (a, l_vec, k_vec, m_lsh, M_lsh);
					vector <long long int> g = every_g (h);
					vector <hash_node *> g_x = match_g_and_x (g);
					All_lsh[size-1].at(j).at(k)->set_hashtables(add_to_L_hashtables (All_lsh[size-1].at(j).at(k)->get_hashtables (), g_x, l_vec, TABLESIZE));
					a.clear ();
					h.clear ();
					g.clear ();
					g_x.clear ();
				}
			}
		}
	}

	// create vectors of each query
	vector<vector<vector<vector<double>>>> GV_of_all_curves;
	for(int i = 0; i < Curves_q.size(); i++) // for every query
	{
		int size = Curves_q[i]->get_p_num(); // size of curve

		vector<vector<vector<double>>> GV_of_all_trav_of_all_sizes;

		for(int j = 0; j < All_Rel.size(); j++) // for each j
		{
			vector<vector<double>> GV_of_all_trav;
			for(int k = 0; k < All_Rel[j][size-1].size(); k++) // for each traversal in i, j cell
			{
				// XAMOS!!!!!!!!!
				vector<double> FinalGV;
				for(int pos = 0; pos < All_Rel[j][size-1].at(k).size(); pos++)
				{
					Point * point = Curves_q[i]->get_specific_point(All_Rel[j][size-1].at(k).at(pos)->get_y());
					vector<double> GV = multiply(G_matr, point);
					for(int gu = 0; gu < GV.size(); gu++)
					{
						FinalGV.push_back(GV[gu]);
					}
					GV.clear();
				}
				GV_of_all_trav.push_back(FinalGV);

			}
			GV_of_all_trav_of_all_sizes.push_back(GV_of_all_trav);
		}
		GV_of_all_curves.push_back(GV_of_all_trav_of_all_sizes);
	}

	vector<LSH_neig *> all_NN;
	for(int i = 0; i < Curves_q.size(); i++) // for every query
	{
		int size = Curves_q[i]->get_p_num();

		v = make_vec_object (GV_of_all_curves[i][size-2].at(size-1));

		double min = -1;
		int min_pos = 0;
		for(int j = 0; j < All_lsh[size-2][size-1].size(); j ++)
		{

			vector <vector <vector <double>>> s = All_lsh[size-2].at(size-1).at(j)->get_s();
			vector <vector <vector <int>>> a = a_for_each_x(v, s, l_vec, k_vec, v->get_dim(), W);
			vector <vector <int>> h = h_for_each_x (a, l_vec, k_vec, m_lsh, M_lsh);
			vector <long long int> g = every_g(h);

			vector <bucket **> hashtables =  All_lsh[size-2].at(size-1).at(j)->get_hashtables();
			vector <hash_node *> posibol = find_possible_nns(hashtables, TABLESIZE, g);
			
			vector <LSH_neig *> NN = find_nn(posibol, g, Curves, Curves_q, 0);

			
			for(int j = 0; j < NN.size(); j ++)
			{	
				if(min == -1)
				{
					min = NN[j]->get_dist();
					min_pos = NN[j]->get_id();
				}

				else 
				{
					if(min > NN[j]->get_dist())
					{
						min = NN[j]->get_dist();
						min_pos = NN[j]->get_id();
					}
				}
			}
		}

		LSH_neig * nn = new LSH_neig();
		nn->set_dist(min);
		nn->set_id(min_pos);
		nn->set_time(0);

		all_NN.push_back(nn);
	}

	return 0;
}
