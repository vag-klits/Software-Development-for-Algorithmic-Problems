#include <iostream>
#include <string>
#include <math.h>
#include <cstring>
#include <vector>
#include <fstream>
#include <random>
#include <stdlib.h>
#include <map>
#include <tgmath.h>
#include "fus_declaration.h"

#define def_K_vec 4
#define def_l_vec 5
#define def_e 0.5

using namespace std;

bool check_args(int argc, const char * argv[], string * input_file, string * query_file, int * k_vec, int * l_vec, double * e, string * output_file)
{

  if(argc == 13)
  {
    for(int i = 0; i < 10; i++)
    {
      if(strcmp(argv[i], "-d") == 0 )
      {
        if(input_file->length() == 0)
          input_file->append(argv[i+1]);
        else
          return false;
      }
      if(strcmp(argv[i], "-q") == 0)
      {
        if(query_file->length() == 0)
        {
          query_file->append(argv[i+1]);
        }
        else
          return false;
      }
      if(strcmp(argv[i], "-k_vec") == 0 )
      {
        if(*k_vec == -1)
          *k_vec = atoi(argv[i+1]);
        else
          return false;
      }
      if(strcmp(argv[i], "-l_vec") == 0 )
      {
        if(*l_vec == -1)
          *l_vec = atoi(argv[i+1]);
        else
          return false;
      }
      if(strcmp(argv[i], "-o") == 0)
      {
        if(output_file->length() == 0)
        {
          output_file->append(argv[i+1]);
        }
        else
          return false;
      }
      if(strcmp(argv[i], "-e") == 0)
      {
        if(*e == 0.0)
        {
          *e = stod(argv[i+1]);
        }
        else
          return false;
      }
    }
  }
  else if(argc == 7)
  {
    for(int i = 1; i < 7; i++)
    {
      if(strcmp(argv[i], "-d") == 0 )
      {
        if(input_file->length() == 0)
          *input_file = argv[i+1];
        else
          return false;
      }
      if(strcmp(argv[i], "-q") == 0)
      {
        if(query_file->length() == 0)
        {
          query_file->append(argv[i+1]);
        }
        else
          return false;
      }
      if(strcmp(argv[i], "-o") == 0)
      {
        if(output_file->length() == 0)
        {
          output_file->append(argv[i+1]);
        }
        else
          return false;
      }
    }
    *e = def_e;
    *k_vec = def_K_vec;
    *l_vec = def_l_vec;
  }
  else if(argc == 1)
  {
    *e = def_e;
    *k_vec = def_K_vec;
    *l_vec = def_l_vec;

    cout << "Please give the input_file" << endl;
    cin >> *input_file;
    cout << "Please give the query_file" << endl;
    cin >> *query_file;
    cout << "Please give the output_file" << endl;
    cin >> *output_file;
  }
  else
  {
    cout<< "ERROR" << endl;
    return false;
  }

  return true;
}

double dtw(curve * P, curve * Q)
{
  return 2.1;
	int dim_p = P->get_p_num();
	int dim_q = Q->get_p_num();

	vector<vector<double> > DTW;
	vector<Point *> points_P = P->get_points();
	vector<Point *> points_Q = Q->get_points();

	double dist = 0.0;

	for(int i = 0; i < dim_p; i++) // points of curve P
	{
		vector<double> line;
		for(int j = 0; j < dim_q; j++) // points of curve Q
		{
			if(i == 0 && j == 0)
				dist = point_dist(points_P[i], points_Q[j]); // first point distance
			else if(i == 0)
				dist = line[j-1] + point_dist(points_P[i], points_Q[j]);
			else if(j == 0)
				dist = DTW[i-1].at(j) + point_dist(points_P[i], points_Q[j]);
			else
			{
				dist = point_dist(points_P[i], points_Q[j]); // point distance

				// find min from near matrix positions
				if(line[j-1] <= DTW[i-1].at(j) && line[j-1] <= DTW[i-1].at(j-1))
					dist += line[j-1];
				else if(DTW[i-1].at(j) <= line[j-1] && DTW[i-1].at(j) <= DTW[i-1].at(j-1))
					dist += DTW[i-1].at(j);
				else
					dist += DTW[i-1].at(j-1);
			}

			line.push_back(dist);
		}
		DTW.push_back(line);
	}
	return DTW[dim_p - 1].at(dim_q - 1);
}

double point_dist(Point * x1, Point * x2)
{
	double pow_x = pow(x1->get_x() - x2->get_x(), 2);
	double pow_y = pow(x1->get_y() - x2->get_y(), 2);

	double res = pow_x + pow_y;
	res = sqrt(res);

	return res;
}



//  FUN TO STORE THE CURVES DATASET
vector <curve *> store_curves (string fname, int * m)
{
  int id=0, i, str_start, str_end;
  string curve_line, id_str, p_num_str, x_str;
  Point *p;
  vector <Point *> pvec;
  curve *c;
  vector <curve *> cvec;

  int max = -1;

  fstream myfile (fname);
  if (myfile.is_open ())
  {
    while (getline (myfile, curve_line))
    {
      c = new curve ();

      str_start=0;
      str_end=curve_line.find ("\t", str_start);

      // cout << "brethike sto " << str_end << endl;

      if (str_start==std::string::npos)
        continue;

      id_str=curve_line.substr (str_start, str_end-str_start);

      c->set_id (id);
      c->set_str_id (id_str);
      // cout << "id=" << id << " -- id_str=" << id_str << endl;

      str_start=str_end+1;
      str_end=curve_line.find ("\t", str_start);
      p_num_str=curve_line.substr (str_start, str_end-str_start);
      // cout << "p_num=" << p_num_str << endl;
      c->set_p_num (stoi (p_num_str));
      if(c->get_p_num() >=10)
        continue;
      // if(min == -1)
      // {
        // min = stoi (p_num_str);
      // }
      if(max < stoi (p_num_str))
        max = stoi (p_num_str);

      for (i=0; i<stoi (p_num_str); i++)
      {
        p = new Point();
        str_start=curve_line.find ("(", str_end+1)+1;

        str_end=curve_line.find (",", str_start);
        x_str=curve_line.substr (str_start, str_end-str_start);
        p->set_x (stod (x_str));
        // cout << "x=" << x_str << endl;

        str_start=str_end+1;
        str_end=curve_line.find (")", str_start);
        x_str=curve_line.substr (str_start, str_end-str_start);
        p->set_y (stod (x_str));
        // cout << "y=" << x_str << endl;

        pvec.push_back (p);
      }

      c->set_points (pvec);
      pvec.clear ();

      cvec.push_back (c);

      id++;
    }
  }

  *m = max;
  return cvec;
}

double find_a(int x, int y)
{
  double a = (double)y/x;
  return a;
}

void put_near_pos(int fl, int i, vector<Point *> * allowed, int y, int x)
{

    if(i - 1 > 0)
    {
        if(fl - 1 > 0)
        {
            bool found = false;
            for(int k = 0; k < allowed->size(); k++)
            {
                if(allowed->at(k)->get_x() == fl - 1 && allowed->at(k)->get_y() == i - 1)
                {
                    found = true;
                    break;
                }
            }
            if(found == false)
            {
                Point * point = new Point(i - 1, fl - 1);
                allowed->push_back(point);
            }

        }
        if(fl + 1 < y)
        {
            bool found = false;
            for(int k = 0; k < allowed->size(); k++)
            {
                if(allowed->at(k)->get_y() == fl + 1 && allowed->at(k)->get_x() == i - 1)
                {
                    found = true;
                    break;
                }
            }
            if(found == false)
            {
                Point * point = new Point(i - 1, fl + 1);
                allowed->push_back(point);
            }

        }

        bool found = false;
        for(int k = 0; k < allowed->size(); k++)
        {
            if(allowed->at(k)->get_y() == fl && allowed->at(k)->get_x() == i-1)
            {
                found = true;
                break;
            }
        }
        if(found == false)
        {
            Point * point = new Point(i-1, fl);
            allowed->push_back(point);
        }
    }
    if(i + 1 < x)
    {
      bool found = false;
      if(fl - 1 > 0)
        {
            bool found = false;
            for(int k = 0; k < allowed->size(); k++)
            {
                if(allowed->at(k)->get_y() == fl - 1 && allowed->at(k)->get_x() == i + 1)
                {
                    found = true;
                    break;
                }
            }
            if(found == false)
            {
                Point * point = new Point(i+1, fl-1);
                allowed->push_back(point);
            }

        }
        if(fl + 1 < y)
        {
            bool found = false;
            for(int k = 0; k < allowed->size(); k++)
            {
                if(allowed->at(k)->get_y() == fl + 1 && allowed->at(k)->get_x() == i + 1)
                {
                    found = true;
                    break;
                }
            }
            if(found == false)
            {
                Point * point = new Point(i + 1, fl + 1);
                allowed->push_back(point);
            }

        }

      for(int k = 0; k < allowed->size(); k++)
      {
        if(allowed->at(k)->get_y() == fl && allowed->at(k)->get_x() == i+1)
        {
          found = true;
          break;
        }
      }
      if(found == false)
      {
        Point * point = new Point(i+1, fl);
        allowed->push_back(point);
      }
    }
    if(fl - 1 > 0)
    {
      bool found = false;
      for(int k = 0; k < allowed->size(); k++)
      {
        if(allowed->at(k)->get_y() == fl - 1 && allowed->at(k)->get_x() == i)
        {
          found = true;
          break;
        }
      }
      if(found == false)
      {
        Point * point = new Point(i, fl - 1);
        allowed->push_back(point);
      }

    }
    if(fl + 1 < y)
    {
      bool found = false;
      for(int k = 0; k < allowed->size(); k++)
      {
        if(allowed->at(k)->get_y() == fl + 1 && allowed->at(k)->get_x() == i)
        {
          found = true;
          break;
        }
      }
      if(found == false)
      {
        Point * point = new Point(i, fl+1);
        allowed->push_back(point);
      }

    }
    return;
}

vector<Point * > create_possible_tr(int x, int y, double a)
{
    vector<Point * > allowed;

    for(int i = 0; i < x; i++)
    {
        double spot_j = a*i;

        int fl = floor(spot_j);
        int ce = ceil(spot_j);

        if(fl >= y)
            break;

        bool found = false;
        for(int k = 0; k < allowed.size(); k++)
        {
            if(allowed[k]->get_y() == fl && allowed[k]->get_x() == i)
            {
                found = true;
                break;
            }
        }
        if(found == false)
        {
            Point * point = new Point(i, fl);
            allowed.push_back(point);
        }

        put_near_pos(fl, i, &allowed, y, x);

        if(ce >= y)
            break;
        if(fl != ce)
        {
            bool found = false;
            for(int k = 0; k < allowed.size(); k++)
            {
                if(allowed[k]->get_x() == ce && allowed[k]->get_y() == i)
                {
                    found = true;
                    break;
                }
            }
            if(found == false)
            {
                Point * point = new Point(ce, i);
                allowed.push_back(point);
            }
        }
        put_near_pos(ce, i, &allowed, y, x);

    }
    return allowed;
}

vector<vector<Point *>> find_relevant(vector<Point *> allowed, vector<Point *> current)
{
    vector<vector<Point *>> new_curr;
    vector<Point *> points = find_near(current.at(current.size() - 1), allowed);

    if(points.size() == 0)
        new_curr.push_back(current);

    for(int i = 0; i < points.size(); i++)
    {
        vector<Point *> new_vec = current;
        new_vec.push_back(points[i]);

        new_curr.push_back(new_vec);
    }
    return new_curr;
}


vector<Point *> find_near(Point * pp, vector<Point *> allowed)
{
    vector<Point *> v;

    int x = pp->get_x();
    int y = pp->get_y();

    bool found = false;

    found = false;
    for(int k = 0; k < allowed.size(); k++)
    {
        if(allowed[k]->get_x() == x && allowed[k]->get_y() == y + 1)
        {
            found = true;
            break;
        }
    }
    if(found == true)
    {
        Point * point = new Point(x, y+1);
        v.push_back(point);
    }

    found = false;
    for(int k = 0; k < allowed.size(); k++)
    {
        if(allowed[k]->get_x() == x + 1 && allowed[k]->get_y() == y)
        {
            found = true;
            break;
        }
    }
    if(found == true)
    {
        Point * point = new Point(x+1, y);
        v.push_back(point);
    }

    found = false;
    for(int k = 0; k < allowed.size(); k++)
    {
        if(allowed[k]->get_x() == x + 1 && allowed[k]->get_y() == y + 1)
        {
            found = true;
            break;
        }
    }
    if(found == true)
    {
        Point * point = new Point(x+1, y+1);
        v.push_back(point);
    }

    return v;

}

double generateGaussian(double mean, double stdDev)
{
    static double spare;
    static bool hasSpare = false;

    if(hasSpare) {
        hasSpare = false;
        return spare * stdDev + mean;
    } else {
        double u, v, s;
        do {
            u = (rand() / ((double)RAND_MAX)) * 2.0 - 1.0;
            v = (rand() / ((double)RAND_MAX)) * 2.0 - 1.0;
            s = u * u + v * v;
        } while (s >= 1.0 || s == 0.0);
        s = sqrt(-2.0 * log(s) / s);
        spare = v * s;
        hasSpare = true;
        return mean + stdDev * u * s;
    }
}

vector<vector<double>> create_G_matr(int d, double e)
{
  vector<vector<double>> G_matr;

  double x, y;
  double S = 0.0;
  int k = -d*log(e)/(e*e);
  for(int i = 0; i < k; i++)
  {
    vector<double> tem_v;
    for(int j = 0; j < d; j++)
    {
      tem_v.push_back(generateGaussian(0,1));
    }
    G_matr.push_back(tem_v);
  }
  return G_matr;
}

vector<double> multiply(vector<vector<double>> G_matr, Point * p)
{
    vector<double> mult;
    for(int i = 0; i < G_matr.size(); i ++)
    {
        mult.push_back(G_matr[i].at(0)*p->get_x() + G_matr[i].at(1)*p->get_y());
    }
    return mult;
}


//////////////////////////////////////////////////////////////////


vector_info * make_vec_object (vector <double> vec)
{
  int static id=0;
  int dim=vec.size ();
  vector_info *v;

  v=new vector_info ();
  v->set_id (id);
  v->set_dim (dim);
  v->set_all_coord (vec);
  id++;

  return v;
}

vector <double> random_s (int dim, double W)
{
	int i;
	vector <double> v;
	random_device rd;
	mt19937 gen (rd ());
	uniform_real_distribution <double> dis (0.0, W);

	for (i=0; i<dim; i++)
		v.push_back (dis (gen));

	return v;
}

vector <vector <vector <double>>> every_s (int L, int K, int dim, double W)
{
	int i, j;
	vector <vector <double>> ks;
	vector <vector <vector <double>>> lks;

	for (i=0; i<L; i++)
	{
		for (j=0; j<K; j++)
			ks.push_back (random_s(dim, W));
		lks.push_back(ks);
		ks.clear();
	}

	return lks;
}

// double compute_w (vector <trueNN_node *> v)
// {
// 	int i, j, size=v.size ();
//   double sum=0.0;
//   double w;
// 	for (i=0; i<size; i++)
//     sum+=v[i]->get_min_dist ();
//
//   return 10.0*sum/size;
// }

vector <int> compute_a (vector_info *x, vector <double> s, double W)
{
	int i, val;
	double dif;

	vector <int> a;

	for (i=0; i<x->get_dim (); i++)
	{
		dif=x->get_specific_coord(i) - s[i];
		val = floor(dif/W);

		a.push_back (val);
	}
	return a;
}

vector <vector <vector <int>>> a_for_each_x (vector_info* x, vector <vector <vector <double>>> s, int L, int K, int dim, double W)
{
	int i, j, z;
	vector <vector <int>> ka;
	vector <vector <vector <int>>> lka;

	for (i=0; i<L; i++)
	{
		for (j=0; j<K; j++)
			ka.push_back(compute_a(x, s[i].at(j), W));

		lka.push_back(ka);
		ka.clear ();
	}

	return lka;
}

int compute_m (vector <vector <vector <vector <int>>>> a)
{
	int i, j, k, l, max=-1;

	for (i=0; i<a.size (); i++)
	{
		for (j=0; j<a[0].size (); j++)
		{
			for (k=0; k<a[0].at(0).size (); k++)
			{
				for (l=0; l<a[0].at(0).at (0).size (); l++)
				{
					if (a[i].at (j).at (k).at (l)>max)
						max=a[i].at (j).at (k).at (l);
				}
			}
		}
	}

	return max + 1;
}

int mymod (int a, int b)
{
  int m=a%b;

  if (m<0)
	{
		if (b<0)
			m=m-b;
		else
		m=m+b;
  }

  return m;
}

int modpow (int x, int y, int p)
{
    int res=1;      // Initialize result

    x=x%p;  // Update x if it is more than or
                // equal to p

    while (y>0)
    {
        // If y is odd, multiply x with result
        if (y&1)
            res=(res*x)%p;

        // y must be even now
        y = y>>1; // y = y/2
        x = (x*x)%p;
    }
    return res;
}

int compute_h (vector <int> a, int d, int m, int M)
{
	int i, h=0, modmult, power;
	long long int mult;

	// A^B mod C = ( (A mod C)^B ) mod C
	// (A * B ) mod C = (A mod C * B mod C) mod C

	for (i=0; i<a.size (); i++)
	{
		power=modpow (m, i, M);
		mult=power*(mymod (a[d-i-1], M));
		h+=mymod (mult, M);
	}

	h=mymod (h, M);

	return h;
}


vector <vector <int>> h_for_each_x (vector <vector <vector <int>>> a, int L, int K, int m, int M)
{
	int i, j;
	vector <int> kh;
	vector <vector <int>> lkh;

	for (i=0; i<a.size (); i++)
	{
		for (j=0; j<L; j++)
      kh.push_back (compute_h (a[i].at(j), a[0].at(0).size(), m, M));

		lkh.push_back (kh);
		kh.clear ();
	}

	return lkh;
}


long long int compute_g (vector <int> h)
{
  long long int g;
  int i;
  string hi_str="";

  for (i=0; i<h.size (); i++)
    hi_str+=to_string (h[i]);

  g=stoll (hi_str);

  return g;
}


vector <long long int> every_g (vector <vector <int>> h)
{
	int i;
	vector <long long int> g;

	for (i=0; i<h.size (); i++)
    g.push_back (compute_g (h[i]));

	return g;
}

int hashing (long long int x, long long int size)
{
	int pos;
	long long int y, mult;

	y=x/size;
	mult=y*size;

	pos=x-mult;

	return pos;
}

vector <hash_node *> match_g_and_x (vector <long long int> g)
{
	int i;
  static int id=0;
	hash_node *hn;
	vector <hash_node *> gval;

	for (i = 0; i < g.size (); i++)
	{
		hn = new hash_node ();
		hn->set_id (id);
		hn->set_g (g[i]);
		gval.push_back (hn);
	}

  id++;
	return gval;
}

vector <bucket **> l_hashtables_init (int size, int l_vec)
{
  int i, j;
  bucket **hashtable;
  vector <bucket **> l_hashtables;

  for (i=0; i<l_vec; i++)
	{
		hashtable = new bucket *[size];
		for (j=0; j<size; j++)
			hashtable[j]=NULL;
		l_hashtables.push_back (hashtable);
	}

  return l_hashtables;
}

vector <bucket **> add_to_L_hashtables (vector <bucket **> l_hashtables, vector <hash_node *> hn, int L, int size)
{
  int i, pos;
  long long int g;
  bucket **hashtable = new bucket *[size];

  for (i=0; i<L; i++)
	{
		g=hn[i]->get_g ();
		pos=hashing (g, size);

		if (hashtable[pos]==NULL)
			hashtable[pos]=new bucket ();

		hashtable[pos]->add_node (hn[i]);
		// l_hashtables.push_back (hashtable);
    l_hashtables[i]=hashtable;
	}

  return l_hashtables;
}


vector <hash_node *> find_possible_nns (vector<bucket **> hashtables, int size, vector<long long int> q_g)
{
  int i, j, k, pos, found;
  bucket **buckets;
  vector <hash_node *> same_bucket;
  vector <hash_node *> nns;
  hash_node * empty = NULL;

  // for (i=0; i < q_g.size (); i++)
  // {
    found=0;
    for (j=0; j<hashtables.size (); j++)
    {
      buckets = hashtables[j];
      pos = hashing (q_g[j], size);
      if(buckets[pos] != NULL)
      {
        for (k=0; k < buckets[pos]->get_all_nodes().size (); k++)
        {
          if (q_g[j] == buckets[pos]->get_specific_hash_node(k)->get_g())
          {
              found=1;
              same_bucket.push_back(buckets[pos]->get_specific_hash_node(k));
          }

        }
      }
    // }
    if (found == 0)
      	same_bucket.push_back(empty);

    // nns.push_back (same_bucket);
    // same_bucket.clear ();
  }

  return same_bucket;
}

// double compute_dist (vector_info *x, vector_info *y)
// {
//   int i;
//   double sum=0.0;

//   for (i=0; i< x->get_dim (); i++)
//     sum+=abs (x->get_specific_coord(i) - y->get_specific_coord(i));

//   return sum;
// }

vector <LSH_neig *> find_nn (vector <hash_node *> posibol, vector <long long int> q_g, vector<curve *> dataset, vector<curve *> queries, clock_t t)
{
  int i, j, k, nearest, dist = 0, near_pos;
  vector <LSH_neig * > nns;
  clock_t time = 0.0;

  // vector <vector <hash_node *>> posibol = find_possible_nns (hashtables, size, q_g);

  for (i=0; i<posibol.size (); i++)
  {
    nearest = -1;
    time = clock();
    // for (j=0; j<posibol[i].size (); j++)
    // {
    	if(posibol[i] == NULL) // no neighbors
    	{
    		near_pos = -1;
    		nearest = -1;
    	}
    	else
    	{
    		int id = posibol[i]->get_id();
    		dist = dtw(dataset.at(id), queries.at(i));       //allaksa to -1

    		if(nearest == -1)
    		{
    			nearest = dist;
    			near_pos = id;
    		}
    		else
    		{
    			if(nearest > dist)
    			{
    				nearest = dist;
    				near_pos = id;
    			}
    		}
    	// }
    }
    time = clock() - time + t;

    LSH_neig * neig = new LSH_neig;
    neig->set_id(near_pos);
    neig->set_dist(nearest);
    neig->set_time((float)time/CLOCKS_PER_SEC);
    nns.push_back(neig);

  }
  return nns;
}


// vector <vector <hash_node *>> find_possible_nns (vector <bucket **> hashtables, int size, vector <long long int> q_g)
// {
//   int i, j, k, pos, found;
//   bucket **buckets;
//   vector <hash_node *> same_bucket;
//   vector <vector <hash_node *>> nns;
//   hash_node * empty = NULL;

//   for (i=0; i < q_g.size (); i++)
//   {
//     found=0;
//     for (j=0; j<hashtables.size (); j++)
//     {
//       buckets=hashtables[j];
//       pos = hashing (q_g[i].at(j), size);
//       if(buckets[pos] != NULL)
//       {
//         for (k=0; k < buckets[pos]->get_all_nodes().size (); k++)
//         {
//           if (q_g[i].at(j) == buckets[pos]->get_specific_hash_node(k)->get_g())
//           {
//               found=1;
//               same_bucket.push_back(buckets[pos]->get_specific_hash_node(k));
//           }

//         }
//       }
//     }
//     if (found == 0)
//         same_bucket.push_back(empty);

//     nns.push_back (same_bucket);
//     same_bucket.clear ();
//   }

//   // cout << "q_g=" << q_g.size () << endl;
//   // for (i=0; i<q_g.size (); i++)
//   // {
//   //   // cout << i << endl;
//   //   for (j=0; j<hashtables.size (); j++)
//   //   {
//   //     buckets=hashtables[j];
//   //     pos=hashing (q_g[i].at (j), size);
//   //     if (buckets[pos]!=NULL)
//   //     {
//   //       for (k=0; k<buckets[pos]->get_all_nodes ().size (); k++)
//   //         same_bucket.push_back (buckets[pos]->get_specific_hash_node (k));
//   //     }
//   //   }
//   //
//   //   // for (j=0; j<same_bucket.size (); j++)
//   //   //   nns.push_back (same_bucket[j]);
//   //   nns.push_back (same_bucket);
//   //   same_bucket.clear ();
//   // }

//   return nns;
// }


// vector <LSH_neig *> find_nn (vector <vector <hash_node *>> posibol, vector <vector <long long int>> q_g, vector<curve *> dataset, vector<curve *> queries, clock_t t)
// {
//   int i, j, k, nearest, dist = 0, near_pos;
//   neighboor_frequency *nfr;
//   vector <LSH_neig * > nns;
//   clock_t time = 0.0;

//   // vector <vector <hash_node *>> posibol = find_possible_nns (hashtables, size, q_g);

//   for (i=0; i<posibol.size (); i++)
//   {
//     nearest = -1;
//     time = clock();
//     for (j=0; j<posibol[i].size (); j++)
//     {

//       if(posibol[i].at(j) == NULL) // no neighbors
//       {
//         near_pos = -1;
//         nearest = -1;
//       }
//       else
//       {
//         int id = posibol[i].at(j)->get_id();
//         dist = dtw(dataset.at(id), queries.at(i));       //allaksa to -1

//         if(nearest == -1)
//         {
//           nearest = dist;
//           near_pos = id;
//         }
//         else
//         {
//           if(nearest > dist)
//           {
//             nearest = dist;
//             near_pos = id;
//           }
//         }
//       }
//     }
//     time = clock() - time + t;

//     LSH_neig * neig = new LSH_neig;
//     neig->set_id(near_pos);
//     neig->set_dist(nearest);
//     neig->set_time((float)time/CLOCKS_PER_SEC);
//     nns.push_back(neig);

//   }
//   return nns;
// }