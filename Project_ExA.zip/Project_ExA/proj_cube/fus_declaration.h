#include <vector>
#include <string>
#include "class.h"

using namespace std;

bool check_args(int argc, const char * argv[], string * input_file, string * query_file, int * k_vec, int * l_vec, double * e, string * output_file);

double dtw(curve * P, curve * Q);
double point_dist(Point * x1, Point * x2);

vector <curve *> store_curves (string fname, int * m);

double find_a(int x, int y);

void put_near_pos(int fl, int i, vector<Point *> * allowed, int y, int x);

vector<Point * > create_possible_tr(int x, int y, double a);

vector<vector<Point *>> find_relevant(vector<Point * > allowed, vector<Point *> init_pos);

vector<Point *> find_near(Point * pp, vector<Point * > allowed);

vector<vector<double>> create_G_matr(int d, double e);

double generateGaussian(double mean, double stdDev);

vector<double> multiply(vector<vector<double>> G_matr, Point * point);

////////////////////////////////////////////////////////////

vector_info * make_vec_object (vector <double>);

vector <vector <vector <double>>> every_s (int, int, int, double);

// double compute_w (vector <trueNN_node *>);

vector <int> compute_a (vector_info *, vector <double>, double);

vector <vector <vector <int>>> a_for_each_x (vector_info*, vector <vector <vector <double>>>, int, int, int, double);

int compute_m (vector <vector <vector <vector <int>>>>);

int compute_h (vector <int> a, int d, int m, int M);

vector <vector <int>> h_for_each_x (vector <vector <vector <int>>>, int , int, int, int);

long long int compute_g (vector <int>);

vector <long long int> every_g (vector <vector <int>>);

int hashing (long long int, long long int);

vector <hash_node *> match_g_and_x (vector <long long int>);

vector <bucket **> l_hashtables_init (int, int);

vector <bucket **> add_to_L_hashtables (vector <bucket **>, vector <hash_node *>, int, int);

vector <vector <hash_node *>> find_possible_nns (vector <bucket **>, int, vector <vector <long long int>>);

double compute_dist (vector_info *, vector_info *);

vector <LSH_neig *> find_nn (vector <vector <hash_node *>>, vector <vector <long long int>>, vector<vector_info *>, vector<vector_info *>, clock_t);

vector <LSH_neig *> find_nn (vector <vector <hash_node *>> posibol, vector <vector <long long int>> q_g, vector<curve *> dataset, vector<curve *> queries, clock_t t);

vector <vector <hash_node *>> find_possible_nns (vector <bucket **> hashtables, int size, vector <vector <long long int>> q_g);
