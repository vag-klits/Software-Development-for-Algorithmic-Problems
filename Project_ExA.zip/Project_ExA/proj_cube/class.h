#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Point
{
	private:
		double x;
		double y;

	public:
    	void set_x (double);
    	void set_y (double);

		double get_x();
		double get_y();

		void print_info ();

		Point(double x, double y);
		Point();

		~Point();

};

class curve
{
  private:
    int id, p_num;
    string str_id;
    vector <Point *> points;

  public:
    void set_id (int);
    void set_p_num (int);
    void set_str_id (string);
    void set_points (vector <Point *>);

    int get_id ();
    int get_p_num ();
    string get_str_id ();
    vector <Point *> get_points ();
    Point *get_specific_point (int);

    // void add_point (point *);      //if needed
    void print_info ();

    curve ();
    ~curve ();
};

class vector_info
{
    private:
        int id, dim;
        std::vector<double> coord;

    public:
        void print_info ();

        void set_id (int);
        void set_dim (int);
				void set_all_coord (std::vector<double>);
        void set_coord (int);

        int get_id ();
        int get_dim ();
        int get_specific_coord (int);
        vector<double> get_coord();

        vector_info ();
        ~vector_info ();
};

class hash_node
{
    private:
        int id;
        long long int g;

    public:
        void set_id (int);
        void set_g (long long int);

        int get_id ();
        long long int get_g ();

        void print_info ();

        hash_node ();
        ~hash_node ();

};


class bucket
{
    private:
        vector <hash_node *> v;

    public:
        void add_node (hash_node *);

        std::vector <hash_node *> get_all_nodes ();
        hash_node *get_specific_hash_node (int);

        bucket ();
        ~bucket ();
};

class trueNN_node
{
	private:
		int id;
		double min_dist;													// changed
		float time;

	public:
		void set_time(float t);
		void set_id (int);
		void set_min_dist (double);								// changed

		int get_id ();
		double get_min_dist ();										// changed
		float get_time();

		void print_info ();

		trueNN_node ();
		~trueNN_node ();
};

class LSH_neig
{
	private:
		int id;
		double dist;
		float time;

	public:
		int get_id();
		double get_dist();
		float get_time();

		void set_time(float tt);
		void set_dist(double dd);
		void set_id(int id);

		LSH_neig();
		~LSH_neig();
};

class lsh
{
  private:
		int l, size;
		vector <vector <vector <double>>> s;
        // vector <bucket **> hashtables;
        unordered_map<string, vector<curve *>> data_map;

        // string p;


  public:
		// void set_m (int);
		// void set_l (int);
		// void set_size (int);
		void set_s (vector <vector <vector <double>>>);
		void set_hashtables (vector <bucket **>);
        // void set_p(string p);

        void set_data(unordered_map<string, vector<curve *>> data);
		// int get_m ();
		// int get_l ();
		// int get_size ();
		vector <vector <vector <double>>> get_s ();
		vector <bucket **> get_hashtables ();
        // string get_p();

    // void insert_in_hashtables (vector<double> v);

    lsh(vector <vector <vector <double>>>, int, int, vector <bucket **>);
		lsh ();
		~lsh();
};
