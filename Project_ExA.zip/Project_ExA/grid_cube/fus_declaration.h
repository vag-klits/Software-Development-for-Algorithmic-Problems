#include <vector>
#include <string>
#include <unordered_map>

using namespace std;

bool check_args(int argc, const char * argv[], string * input_file, string * query_file, int * k_vec, int * l_grid, int * M, string * output_file);

double dtw(curve * P, curve * Q);
double point_dist(Point * x1, Point * x2);

vector<int> create_Gd(int dim, int delta);
vector<double> create_t(int dim);

vector<vector<double>> create_grid_curve(vector<curve *> P, vector<int> Gd, vector<double> t, int size);

vector <curve *> store_curves (string fname, int * m);

/////////////////////////////////////

vector <vector_info *> make_vecs_objects (vector <vector <double>>);

vector <double> random_s (int, double);

vector <vector <vector <double>>> every_s (int, int, int, double);

double compute_w (vector <trueNN_node *>);

vector <int> compute_a (vector_info *, vector <double>);

vector <vector <vector <int>>> a_for_each_x (vector_info *, vector <vector <vector <double>>>, int, int, int, double);

int compute_m (vector <vector <vector <vector <int>>>>);

int mymod (int, int);

int modpow (int, int, int);

int compute_h (vector <int>, int, int, int);

vector < vector <vector <int>>> h_for_each_x (vector <vector <vector <vector <int>>>>, int, int, int, int);

long long int compute_g (vector <int>);

vector < vector <long long int>> every_g (vector <vector <vector <int>>>);

int hashing (long long int, long long int);

vector < vector <hash_node *>> match_g_and_x (vector <vector <long long int>> g);

vector <bucket **> make_L_hashtables (vector <vector <hash_node *>>, int, int);

vector <vector <hash_node *>> find_possible_nns (vector <bucket **>, int, vector <vector <long long int>>);

vector<LSH_neig *> find_NN(unordered_map<string, vector<vector_info *>> All_neigs, vector<curve *> P, vector<curve *> queries, 
							int L, int Mi, int prob, int M, int m, vector<map<long long int, bool>> All_decision_map,  
							vector <vector <vector <double>>> s, vector <vector_info *> q_all_vecs, vector <vector_info *> all_vecs, double W);


// vector <LSH_neig *> find_nn (vector <vector <hash_node *>> posibol, vector <vector <long long int>> q_g, vector<vector_info *> dataset, vector<vector_info *> queries, clock_t time);

double compute_dist (vector_info *, vector_info *);

vector <trueNN_node *> find_trueNN (vector <curve *>, vector <curve *>);

// bool write_output(string output_file, vector<LSH_neig *> NN, vector<trueNN_node *> tr, vector<vector_info *> queries, vector<vector_info *> dataset);
bool write_output(string output_file, vector<LSH_neig *> NN, vector<trueNN_node *> tr, vector<curve *> queries, vector<curve *> dataset);


bool calc_f();

vector<string> find_near_vertices(string p);


