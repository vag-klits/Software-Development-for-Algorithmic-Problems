#include <iostream>
#include <cmath>
#include <vector>
#include <map>
#include <unordered_map>
#include "class.h"
#include "fus_declaration.h"

#define d 2
#define mysize 10
#define L 4
#define TABLESIZE 1024
#define l_grid 4

using namespace std;

int main(int argc, char const *argv[])
{

	string input_file, query_file, output_file;
	int k_hyper = -1, probes = -1, Mi = -1;

	check_args(argc, argv, &input_file, & query_file, &k_hyper, &Mi, &probes, &output_file);

	int m, q_m;

	vector<curve *> P = store_curves(input_file, &m);
	vector<curve *> queries = store_curves(query_file, &q_m);

	int delta = 4 * d * m - 7, q_delta=4*d*q_m;

	vector<int> Gd = create_Gd(d, delta), q_Gd=create_Gd(d, q_delta);

	vector<vector<double>> all_t;
	vector<vector<vector<double>>> all_H, q_all_H;

	for(int i = 0; i < l_grid; i++)
	{
		vector<double> t = create_t(d);
		vector<vector<double>> H, q_H;
		H = create_grid_curve(P, Gd, t, mysize);
		q_H=create_grid_curve(queries, q_Gd, t, mysize);

		all_t.push_back(t);
		all_H.push_back(H);
		q_all_H.push_back (q_H);
	}


	int i, j, m_lsh, M;
	vector <vector <vector_info *>> all_vecs, q_all_vecs;

	for (i=0; i<all_H.size (); i++)
		all_vecs.push_back (make_vecs_objects (all_H[i]));

	for (i=0; i<q_all_H.size (); i++)
		q_all_vecs.push_back (make_vecs_objects (q_all_H[i]));

	vector< vector <vector <vector <double>>>> All_s;
	vector<vector<map<long long int, bool>>> All_decision_map;
	vector<unordered_map<string, vector<vector_info *>>> All_neigs;

	vector <trueNN_node *> tr = find_trueNN (P, queries);

	double R=-1.0, W=compute_w (tr);
	for (i=0; i<l_grid; i++)
	{
		vector <vector <vector <double>>> s;
		vector <vector <vector <vector <int>>>> a, q_a;
		vector <vector <vector <int>>> h, q_h;
		vector <vector <long long int>> g, q_g;
		vector <vector <hash_node *>> g_x;
		vector <bucket **> hashtables;
		
		s = every_s (L, k_hyper, all_vecs[i].at (0)->get_dim(), W);

		for (j=0; j<all_vecs[i].size(); j++)
	    a.push_back(a_for_each_x (all_vecs[i].at (j), s, L, k_hyper, all_vecs[i].at (0)->get_dim(), W));

		m_lsh = compute_m(a);
		// m_lsh++;					//possible

		M=pow (2, 32/k_hyper);
	  	h=h_for_each_x (a, L, k_hyper, m_lsh, M);
	  	g=every_g (h);

		unordered_map<string, vector<vector_info *>> data_map;

		vector<map<long long int, bool>> decision_map;
		map<long long int, bool>::iterator it;

		for(int ii = 0; ii < g.size(); ii++)
		{
		    string p="";
		    for(int j = 0; j < g[ii].size(); j++)
		    {
			    bool res;
		      
		    	if(decision_map.size() > j)
		      	{
		        	it = decision_map[j].find(g[ii].at(j));
		        	if(it == decision_map[j].end())
		        	{
		        	 	res = calc_f();
		          		decision_map[j][g[ii].at(j)] = res;
		        	}
		        	else
			          	res = decision_map[j][g[ii].at(j)];

		        	if(res == true)
		          		p += '1';
		        	else 
		          		p +='0';
		      	}
		      	else
		      	{
		        	res = calc_f();
		        	if(res == true)
		          		p += '1';
		        	else 
		          		p +='0';

		        	map<long long int, bool> temp_map;
		        	temp_map[g[ii].at(j)] = res;
		        	decision_map.push_back(temp_map);

		      	}
		    }
		    data_map[p].push_back(all_vecs[i][ii]); // store data set
	  	}
	  	All_decision_map.push_back(decision_map);
	    All_neigs.push_back(data_map);
	    All_s.push_back(s);
	}

	vector<vector<LSH_neig *>> All_distances;	
	for (i=0; i<l_grid; i++)
	{
  		vector<LSH_neig *> distances = find_NN(All_neigs[i], P, queries, L, Mi, probes, M, m, All_decision_map[i], All_s[i], q_all_vecs[i], all_vecs[i], W);
  		All_distances.push_back(distances);

	}

	vector<LSH_neig *> min_distances;

	for(int i = 0; i < All_distances[0].size(); i++)
		min_distances.push_back(All_distances[0][i]);


	for(int i = 0; i < All_distances.size(); i ++)
	{
		for(int j = 0; j < All_distances[i].size(); j++)
		{
			if(All_distances[i][j]->get_dist() < min_distances[j]->get_dist() && All_distances[i][j]->get_dist() != -1)
				min_distances[j] = All_distances[i][j]; 
		}
	}

  	if(write_output(output_file, min_distances, tr, queries, P) != true)
  		return -1;

	return 0;
}
