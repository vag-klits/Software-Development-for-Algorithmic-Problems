#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <random>
#include <stdlib.h>
#include <unordered_map>
#include <map>
#include "classes.h"
#include "funs_declaration.h"

using namespace std;

// #define W 4656.0

bool check_args(int argc, const char * argv[], string * input_file, string * query_file, int * k, int * m, int * prob, string * output_file)
{

  if(argc == 13)
  { 
    for(int i = 0; i < 12; i++)
    {
      if(strcmp(argv[i], "-d") == 0 )
      {
        if(input_file->length() == 0)
          input_file->append(argv[i+1]);
        else 
          return false;
      }
      if(strcmp(argv[i], "-q") == 0)
      {
        if(query_file->length() == 0)
        {
          query_file->append(argv[i+1]);
        }
        else 
          return false;
      }
      if(strcmp(argv[i], "-k") == 0 )
      {
        if(*k == -1)
          *k = atoi(argv[i+1]);
        else 
          return false;
      }
      if(strcmp(argv[i], "-M") == 0 )
      {
        if(*m == -1)
          *m = atoi(argv[i+1]);
        else 
          return false;
      }
      if(strcmp(argv[i], "-probes") == 0 )
      {
        if(*prob == -1)
          *prob = atoi(argv[i+1]);
        else 
          return false;
      }
      if(strcmp(argv[i], "-o") == 0)
      {
        if(output_file->length() == 0)
        {
          output_file->append(argv[i+1]);
        }
        else 
          return false;
      }
    }
  }
  else if(argc == 7)
  {
    for(int i = 1; i < 7; i++)
    {
      if(strcmp(argv[i], "-d") == 0 )
      {
        if(input_file->length() == 0)
          *input_file = argv[i+1];
        else 
          return false;
      }
      if(strcmp(argv[i], "-q") == 0)
      {
        if(query_file->length() == 0)
        {
          query_file->append(argv[i+1]);
        }
        else 
          return false;
      }
      if(strcmp(argv[i], "-o") == 0)
      {
        if(output_file->length() == 0)
        {
          output_file->append(argv[i+1]);
        }
        else 
          return false;
      }
    }

    *k = def_K;
    *m = def_M;
    *prob = PROB;
  }
  else if(argc == 1)
  {
    *k = def_K;
    *m = def_M;
    *prob = PROB;

    cout << "Please give the input_file" << endl;
    cin >> *input_file;
    cout << "Please give the query_file" << endl;
    cin >> *query_file;
    cout << "Please give the output_file" << endl;
    cin >> *output_file;
  }
  else 
  {

    cout<< "ERROR" << endl;
    return false;
  }

  return true;
}

vector<vector_info *> store_set (string fname)
{
	string line, vec_line, id_str, coord_str;
	vector<vector_info *> dataset;
	int id = 0, dim, pos_space1, pos_space2;
	vector_info *vec_ptr;

	fstream myfile (fname);
	if (myfile.is_open ())
	{
		while (getline (myfile, vec_line))
		{
			dim=0;
			vec_ptr=new vector_info ();

			pos_space1=0;
			pos_space2=vec_line.find (" ", pos_space1+1);

			if (pos_space2==std::string::npos)
				continue;

			id_str=vec_line.substr (pos_space1, pos_space2-pos_space1);

     	vec_ptr->set_id (id);
			vec_ptr->set_str_id (id_str);

			pos_space1=pos_space2+1;
			pos_space2=vec_line.find (" ", pos_space1);

			while (pos_space2!=std::string::npos)
			{
				if (pos_space2==std::string::npos)
					continue;

				coord_str=vec_line.substr (pos_space1, pos_space2-pos_space1);

				vec_ptr->set_coord (stoi (coord_str));

				dim++;

				pos_space1=pos_space2+1;
				pos_space2=vec_line.find (" ", pos_space1);
			}

			vec_ptr->set_dim (dim);
			dataset.push_back (vec_ptr);

			id++;
		}

		myfile.close();
	}

	return dataset;
}

vector <vector_info *> store_queries(string query_file, double * R)
{
	string::size_type sz;
	string line, vec_line, id_str, coord_str;
	bool first_line = true;
	
	vector<vector_info *> dataset;
	
	int id=0, dim, pos_space1, pos_space2;
	
	vector_info *vec_ptr;

	fstream myfile(query_file);

	if(myfile.is_open())
	{

		while (getline(myfile, vec_line))
		{
			dim = 0;
			vec_ptr = new vector_info ();

			pos_space1 = 0;
			pos_space2 = vec_line.find (" ", pos_space1 + 1);

			if (pos_space2 == string::npos)
			{
				*R = stod(vec_line, &sz);
				continue;
			}

			id_str = vec_line.substr(pos_space1, pos_space2-pos_space1);

     	vec_ptr->set_id (id);
			vec_ptr->set_str_id (id_str);

			pos_space1 = pos_space2+1;
			pos_space2 = vec_line.find (" ", pos_space1);

			
			while (pos_space2 != string::npos)
			{
				if (pos_space2==string::npos)
					continue;

				coord_str=vec_line.substr (pos_space1, pos_space2-pos_space1);

				vec_ptr->set_coord (stoi (coord_str));

				dim++;

				pos_space1=pos_space2+1;
				pos_space2=vec_line.find (" ", pos_space1);
			}

			if(dim == 0 && first_line == true)
			{
				*R = stod(id_str, &sz);
			}
			else
			{
				vec_ptr->set_dim (dim);
				dataset.push_back (vec_ptr);
	
				id++;

			}
			first_line = false;

		}

		myfile.close();
	}

	return dataset;

}

vector <double> random_s (int dim)
{
	int i;
	vector <double> v;
	random_device rd;
	mt19937 gen (rd ());
	uniform_real_distribution <double> dis (0.0, W);

	for (i=0; i<dim; i++)
		v.push_back (dis (gen));

	return v;
}


vector <vector <vector <double>>> every_s (int L, int K, int dim)
{
	int i, j;
	vector <vector <double>> ks;
	vector <vector <vector <double>>> lks;

	for (i = 0; i < L; i++)
	{
		for (j = 0; j < K; j++)
			ks.push_back(random_s(dim));
		lks.push_back(ks);
		ks.clear ();
	}
	return lks;
}

vector <int> compute_a (vector_info *x, vector <double> s)
{
	int i, val;
	double dif;

	vector <int> a;

	for (i=0; i<x->get_dim (); i++)
	{
		dif=x->get_specific_coord (i)-s[i];
		val=floor (dif/W);

		a.push_back (val);
	}
	return a;
}


vector <vector <vector <int>>> a_for_each_x (vector_info* x, vector <vector <vector <double>>> s, int L, int K, int dim)
{
	int i, j, z;
	vector <vector <int>> ka;
	vector <vector <vector <int>>> lka;

	for (i=0; i<L; i++)
	{
		for (j=0; j<K; j++)
			ka.push_back (compute_a (x, s[i].at (j)));

		lka.push_back (ka);
		ka.clear ();
	}

	return lka;
}


int compute_m (vector <vector <vector <vector <int>>>> a)
{
	int i, j, k, l, max=-1;

	for (i=0; i<a.size (); i++)
	{
		for (j=0; j<a[0].size (); j++)
		{
			for (k=0; k<a[0].at(0).size (); k++)
			{
				for (l=0; l<a[0].at(0).at (0).size (); l++)
				{
					if (a[i].at (j).at (k).at (l)>max)
						max=a[i].at (j).at (k).at (l);
				}
			}
		}
	}

	return max + 1;
}


int mymod (int a, int b)
{
  int m=a%b;

  if (m<0)
	{
		if (b<0)
			m=m-b;
		else
		m=m+b;
  }

  return m;
}


int modpow (int x, int y, int p)
{
    int res=1;      // Initialize result

    x=x%p;  // Update x if it is more than or
                // equal to p

    while (y>0)
    {
        // If y is odd, multiply x with result
        if (y&1)
            res=(res*x)%p;

        // y must be even now
        y = y>>1; // y = y/2
        x = (x*x)%p;
    }
    return res;
}


int compute_h (vector <int> a, int d, int m, int M)
{
	int i, h = 0, modmult, power;
	long long int mult;

	// A^B mod C = ( (A mod C)^B ) mod C
	// (A * B ) mod C = (A mod C * B mod C) mod C

	for(i = 0; i < a.size(); i++)
	{
		power = modpow (m, i, M);
		mult = power * (mymod(a[d-i-1], M));
		h += mymod(mult, M);
	}

	h = mymod(h, M);

	return h;
}

vector <vector <vector <int>>> h_for_each_x (vector <vector <vector <vector <int>>>> a, int L, int K, int m, int M)
{
	int i, j, t, z;
	vector <int> kh;
	vector <vector <int>> lkh;
	vector <vector <vector <int>>> xlkh;

	for (i=0; i<a.size (); i++)
	{
		for (j=0; j<L; j++)
		{
			for (t=0; t<K; t++)
				kh.push_back (compute_h (a[i].at (j).at(t), a[0].at (0).at (0).size (), m, M));

			lkh.push_back (kh);
			kh.clear ();
			}

			xlkh.push_back (lkh);
			lkh.clear ();
	}


	return xlkh;
}


long long int compute_g (vector <int> h)
{
  long long int g;
  int i;
  string hi_str="";

  for (i=0; i<h.size (); i++)
    hi_str+=to_string (h[i]);

  g=stoll (hi_str);

  return g;
}


vector <vector <long long int>> every_g (vector <vector <vector <int>>> h)
{
	int i, j;
	vector <long long int> g;
	vector <vector <long long int>> xg;

	for (i=0; i<h.size (); i++)
	{
		for (j=0; j<h[0].size (); j++)
			g.push_back (compute_g (h[i].at(j)));

		xg.push_back (g);
		g.clear ();
	}

	return xg;
}


int hashing (long long int x, long long int size)
{
	int pos;
	long long int y, mult;

	y=x/size;
	mult=y*size;

	pos=x-mult;

	return pos;
}

vector <vector <hash_node *>> match_g_and_x (vector <vector <long long int>> g)
{
	int i, j;
	hash_node *hn;
	vector <hash_node *> gval;
	vector <vector <hash_node *>> l_gval;

	for (j=0; j<g[0].size (); j++)
	{
		for (i=0; i<g.size (); i++)
		{
			hn=new hash_node ();
			hn->set_id (i);
			hn->set_g (g[i].at (j));
			gval.push_back (hn);
		}

		l_gval.push_back (gval);
		gval.clear ();
	}


	return l_gval;
}

vector <bucket **> make_L_hashtables (vector <vector <hash_node *>> hn, int L, int size)
{
	int i, j, pos;
	long long int g;
	vector <bucket **> l_hashtables;
	bucket ** hashtable = new bucket * [size];

	for (i = 0; i < L; i++)
	{
		for (j = 0; j < size; j++)
			hashtable[j] = NULL;

		for (j = 0; j < hn[0].size(); j++)
		{
			g = hn[i].at(j)->get_g();
			pos = hashing(g, size);

			if (hashtable[pos] == NULL)
				hashtable[pos] = new bucket;

			hashtable[pos]->add_node(hn[i].at (j));
		}
		l_hashtables.push_back(hashtable);
	}

	return l_hashtables;

}

bool calc_f()
{
	random_device rd;
	mt19937 gen (rd ());
	uniform_int_distribution <> dis (0, 1);

	if(dis(gen) == 0)
		return false;
	return true;
}


vector<string> find_near_vertices(string p)
{
	vector<string> str_vec;
	str_vec.push_back(p);
	string temp_str;
	for(int i = 0; i < p.length(); i++)
	{
		temp_str = p;
		if(temp_str[i] == '0')
			temp_str[i] = '1';
		else
			temp_str[i] = '0';
		str_vec.push_back(temp_str);

	}
	return str_vec;
}

int manhattan_dist(vector<int> v1, vector<int> v2)
{
	if(v1.size() != v2.size())
		return -1;

	int sum = 0;
	for(int i = 0; i < v1.size(); i++)
		sum += abs(v1[i] - v2[i]);

	return sum;
}


vector <trueNN_node *> find_trueNN(vector <vector_info *> dataset, vector <vector_info *> queries)
{
	int i, j, m, sum, min_sum, posmin;
	trueNN_node *node;
	vector <trueNN_node *> trueNN;
	clock_t time;

	for (i = 0; i<queries.size (); i++)
	{
		time = clock();
		node=new trueNN_node ();

		for (j = 0; j<dataset.size (); j++)
		{
			sum = manhattan_dist(dataset[j]->get_coord(), queries[i]->get_coord());

			if (j == 0)
			{
        		posmin = j;
        		min_sum = sum;
			}
			else
			{
				if (sum < min_sum)
				{
					min_sum = sum;
          			posmin = j;
				}
			}
		}
		time = clock() - time;
    	node->set_id (posmin);
    	node->set_min_dist (min_sum);
    	node->set_time((float)time/CLOCKS_PER_SEC);
		trueNN.push_back (node);
	}
	return trueNN;
}

 
vector<LSH_neig *> find_NN(unordered_map<string, vector<vector_info *>> data_map,vector <vector_info *> dataset, vector <vector_info *> queries, 
													int L, int M, int prob, int Mi, int mi, vector<map<long long int, bool>> decision_map,   vector <vector <vector <double>>> s)
{
	map<long long int, bool>::iterator it;
  vector<LSH_neig *> distances;

	for(int qu = 0; qu < queries.size(); qu++)
  {
    vector<vector<vector<int>>> a_vec;

    vector_info * cur_vec = queries[qu];
    vector<vector<int>> tem_a_vec;

    for(int tables = 0; tables < s.size(); tables++)
    {
      for(int j = 0; j < L; j++)
          tem_a_vec.push_back(compute_a(cur_vec, s[tables].at(j)));

      a_vec.push_back(tem_a_vec);
      tem_a_vec.clear();
    }


    vector<int> h_vec;
    string p = "" ;
    for(int j = 0; j < a_vec.size(); j++)
    {  
      bool res;
      for(int i = 0; i < a_vec[j].size(); i++)
      { 
        h_vec.push_back(compute_h(a_vec[j].at(i), dataset[0]->get_dim(), mi, Mi));
      }

      long long int g_qu = compute_g(h_vec);
      h_vec.clear();

      it = decision_map[j].find(g_qu);
      if(it == decision_map[j].end())
      {
        res = calc_f();
        decision_map[j][g_qu] = res;

      }
      else
        res = decision_map[j].at(g_qu);

      if(res == true)
        p += '1';
      else 
        p +='0';
    }

    vector<string> near_ver = find_near_vertices(p); // find the near vertices 

    unordered_map<string, vector<vector_info *>>::iterator it;

    int min = -1;
    int minpos = -1;

    clock_t time = clock();

    for(int ver = 0; ver < near_ver.size(); ver++) // for all near vertices
    {
    	int count = 0;

      it = data_map.find(near_ver[ver]);
      if(it != data_map.end()) 
      {
        vector<vector_info *> v = data_map[near_ver[ver]];
        int i;
        for(i = 0; i < v.size(); i ++)
        {
          int dist = manhattan_dist(v[i]->get_coord(), queries[qu]->get_coord());

          count ++;
          if(min == -1 || min > dist)
          {
            min = dist;
            minpos = v[i]->get_id();
          }
          if(count == M)
          {
            break;
          }
        }
        // if(i != v.size())
          // break;
      }
      // else
      	// cout<<"nop"<<endl;
      if(ver >= prob)
        break;
    }
    time = clock() - time; // time needed to find the nearest neig

    LSH_neig * neig = new LSH_neig;
    neig->set_id(minpos);
    neig->set_dist(min);
    neig->set_time((float)time/CLOCKS_PER_SEC);
    distances.push_back(neig);
 	}

 	return distances;
}

 
vector<map<int, LSH_neig *>> find_R_NN(unordered_map<string, vector<vector_info *>> data_map,vector <vector_info *> dataset, vector <vector_info *> queries, 
													int L, int M, int prob, int Mi, int mi, vector<map<long long int, bool>> decision_map, vector <vector <vector <double>>> s, double R)
{
	map<long long int, bool>::iterator it;
  vector <map<int, LSH_neig *>> all_distances;

	for(int qu = 0; qu < queries.size(); qu++)
  {
    vector<vector<vector<int>>> a_vec;

    vector_info * cur_vec = queries[qu];
    vector<vector<int>> tem_a_vec;

    for(int tables = 0; tables < s.size(); tables++)
    {
      for(int j = 0; j < L; j++)
          tem_a_vec.push_back(compute_a(cur_vec, s[tables].at(j)));

      a_vec.push_back(tem_a_vec);
      tem_a_vec.clear();
    }


    vector<int> h_vec;
    string p;
    for(int j = 0; j < a_vec.size(); j++)
    {  
      bool res;
      for(int i = 0; i < a_vec[j].size(); i++)
      { 
        h_vec.push_back(compute_h(a_vec[j].at(i), dataset[0]->get_dim(), mi, Mi));
      }

      long long int g_qu = compute_g(h_vec);
      h_vec.clear();

      it = decision_map[j].find(g_qu);
      if(it == decision_map[j].end())
      {
        res = calc_f();
        decision_map[j][g_qu] = res;

      }
      else
        res = decision_map[j].at(g_qu);

      if(res == true)
        p += '1';
      else 
        p +='0';
    }

    vector<string> near_ver = find_near_vertices(p); // find the near vertices 

    unordered_map<string, vector<vector_info *>>::iterator it;

    // int min = -1;
    // int minpos = -1;
    int count = 0;

    // clock_t time = clock();

    map<int, LSH_neig *> distances;

    for(int ver = 0; ver < near_ver.size(); ver++) // for all near vertices
    {
      it = data_map.find(near_ver[ver]);
      if(it != data_map.end()) 
      {
        vector<vector_info *> v = data_map[near_ver[ver]];
        int i;
        for(i = 0; i < v.size(); i ++)
        {
          int dist = manhattan_dist(v[i]->get_coord(), queries[qu]->get_coord());

          count ++;
          if(dist <= R)
          {
            LSH_neig * neig = new LSH_neig;
    				neig->set_id(v[i]->get_id());
    				neig->set_dist(dist);
    				neig->set_time((float)0.0);
    				distances[v[i]->get_id()] = neig;
          }
          if(count == M)
          {
            break;
          }
        }
        if(i != v.size())
          break;
      }
      if(ver >= prob)
        break;
    }
    // time = clock() - time; // time needed to find the nearest neig

    if(distances.size() == 0)
    {
    	LSH_neig * neig = new LSH_neig;
    	neig->set_id(-1);
    	neig->set_dist(-1);
    	neig->set_time(0.0);
    	distances[-1] = neig;
    }
    all_distances.push_back(distances);
 	}

 	return all_distances;
}



bool write_output(string output_file, vector<LSH_neig *> NN, vector<trueNN_node *> tr, vector <map <int, LSH_neig *>> R_NNs, vector<vector_info *> queries, vector<vector_info *> dataset)
{
	ofstream file (output_file);

	double max = -1.0;
	double count = 0.0;
	double av_time = 0.0;
	for(int i = 0; i < NN.size(); i ++) // for every meighbor
	{
		file << "Query: ";
		file << queries[i]->get_str_id()<<endl;

		if(NN[i]->get_id() != -1)
		{

			file << "Nearest neighbor: ";
			file << dataset[NN[i]->get_id()]->get_str_id() << endl;
		
			file << "DistanceLSH: ";
			file << NN[i]->get_dist() << endl;

			file << "DistanceTrue: ";
			file << tr[i]->get_min_dist()<<endl;
			count += (double)NN[i]->get_dist()/tr[i]->get_min_dist();

			if((double)NN[i]->get_dist()/tr[i]->get_min_dist() > max)
				max = (double)NN[i]->get_dist()/tr[i]->get_min_dist();

			file << "tLSH: ";
			file << NN[i]->get_time() << endl;

			av_time += NN[i]->get_time(); 

			file << "tTrue: ";
			file << tr[i]->get_time()<<endl;

			file << "R-near neighbors: "<<endl;
			for(std::map<int, LSH_neig *>::iterator j = R_NNs[i].begin(); j != R_NNs[i].end(); j++)
			{
				if(j->first != -1)
					file << dataset[j->second->get_id()]->get_str_id() <<endl;
				else 
					file << "No neighbors in Range R"<<endl;
			}
		}
		else 
		{
			file << "Nearest neighbor: No neighbor with LSH"<<endl;
			
			file << "DistanceLSH: inf"<<endl;
			
			file << "DistanceTrue: ";
			file << tr[i]->get_min_dist()<<endl;
		}
		file << endl;

	}

	file.close();

	cout << "Average AF = "<< (float)count/queries.size() <<endl;
	cout << "Max AF = " << max << endl;

	cout << "Average time = " << av_time << endl;

	return true;
}




