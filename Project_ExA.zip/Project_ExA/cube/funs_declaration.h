#include <vector>
#include <string>
#include <map>
#include <unordered_map>
#include <cstring>

#define def_K 3
#define def_M 10
#define PROB 2
#define W 7656.0

using namespace std;

bool check_args(int argc, const char * argv[], string * input_file, string * query_file, int * k, int * m, int * prob, string * output_file);

vector <vector_info *> store_set(string input_file);

vector <vector_info *> store_queries(string query_file, double * R);

bool calc_f();

vector <double> random_s (int);

vector <vector <vector <double>>> every_s (int, int, int);

vector <int> compute_a (vector_info *, vector <double>);

vector <vector <vector <int>>> a_for_each_x (vector_info *, vector <vector <vector <double>>>, int, int, int);

int compute_m (vector <vector <vector <vector <int>>>>);

int mymod (int, int);

int modpow (int, int, int);

int compute_h (vector <int>, int, int, int);

vector < vector <vector <int>>> h_for_each_x (vector <vector <vector <vector <int>>>>, int, int, int, int);

long long int compute_g (vector <int>);

vector < vector <long long int>> every_g (vector <vector <vector <int>>>);

int hashing (long long int, long long int);

vector < vector <hash_node *>> match_g_and_x (vector <vector <long long int>> g);

vector <bucket **> make_L_hashtables (vector <vector <hash_node *>>, int, int);

vector<string> find_near_vertices(string p);

int manhattan_dist(vector<int> v1, vector<int> v2);

vector <trueNN_node *> find_trueNN (vector <vector_info *> dataset, vector <vector_info *> queries);

vector<LSH_neig *> find_NN(unordered_map<string, vector<vector_info *>> data_map,vector <vector_info *> dataset, vector <vector_info *> queries, 
							int L, int M, int prob, int Mi, int mi, vector<map<long long int, bool>> decision_map,   vector <vector <vector <double>>> s);

bool write_output(string output_file, vector<LSH_neig *> NN, vector<trueNN_node *> tr, vector <map <int, LSH_neig *>> R_NNs, vector<vector_info *> queries, vector<vector_info *> dataset);

vector<map<int, LSH_neig *>> find_R_NN(unordered_map<string, vector<vector_info *>> data_map,vector <vector_info *> dataset, vector <vector_info *> queries, 
									 int L, int M, int prob, int Mi, int mi, vector<map<long long int, bool>> decision_map, vector <vector <vector <double>>> s, double R);