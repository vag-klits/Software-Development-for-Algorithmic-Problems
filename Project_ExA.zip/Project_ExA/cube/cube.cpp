#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <cmath>
#include <unordered_map> 
#include <map>
#include "classes.h"
#include "funs_declaration.h"

#define L 4

using namespace std;

int main(int argc, char const *argv[])
{

  string input_file, query_file, output_file;
  int K = -1, M = -1, prob = -1, mi, Mi; 
  double R;

  if(check_args(argc, argv, &input_file, &query_file, &K, &M, &prob, &output_file) == false)
  {
    return -1;
  }

  vector <vector_info *> dataset, queries;

  vector <vector <vector <double>>> s;
  vector <vector <vector <vector <int>>>> a;
  vector <vector <vector <int>>> h;
  vector <vector <long long int>> g;
  vector <vector <hash_node *>> g_x;  

  dataset = store_set(input_file); //load dataset
  queries = store_queries(query_file, &R); // load queries

  s = every_s(K, L, dataset[0]->get_dim());

  for (int i = 0; i < dataset.size(); i++)
    a.push_back (a_for_each_x(dataset[i], s, K , L, dataset[0]->get_dim()));

  mi = compute_m(a);
  // mi++;

  Mi = pow(2, 32/L);
  h = h_for_each_x(a, K, L, mi, Mi);
  g = every_g(h); // g for dataset

 // store dataset 
  unordered_map<string, vector<vector_info *>> data_map;

  vector<map<long long int, bool>> decision_map;
  map<long long int, bool>::iterator it;

  vector <trueNN_node *> tr = find_trueNN (dataset, queries);

  // cout<<g[0].size()<<endl;
  for(int i = 0; i < g.size(); i++)
  {
    string p="";
    for(int j = 0; j < g[i].size(); j++)
    {
      bool res;
      
      if(decision_map.size() > j)
      {
        it = decision_map[j].find(g[i].at(j));
        if(it == decision_map[j].end())
        {
          res = calc_f();
          decision_map[j][g[i].at(j)] = res;
        }
        else
          res = decision_map[j][g[i].at(j)];

        if(res == true)
          p += '1';
        else 
          p +='0';
      }
      else
      {
        res = calc_f();
        if(res == true)
          p += '1';
        else 
          p +='0';

        map<long long int, bool> temp_map;
        temp_map[g[i].at(j)] = res;
        decision_map.push_back(temp_map);

      }
    }
    // cout<<p<<endl;
    data_map[p].push_back(dataset[i]); // store data set
  }

  // cout<<"decision "<<decision_map.size()<<endl;

  // for(int tt = 0; tt < decision_map.size(); tt++)
  // {
    // cout<<decision_map[tt].size()<<endl;
  // }
  // cout<<"map "<<data_map.size()<<endl;

  // cout<<data_map.size()<<endl;
  //find neighbors for all queries
  vector<LSH_neig *> distances = find_NN(data_map, dataset, queries, L, M, prob, Mi, mi, decision_map, s);

  vector<map<int, LSH_neig *>> R_NN = find_R_NN(data_map, dataset, queries, L, M, prob, Mi, mi, decision_map, s, R);  

  if(write_output(output_file, distances, tr, R_NN, queries, dataset) != true)
    return -1;
  
  return 0;
}
